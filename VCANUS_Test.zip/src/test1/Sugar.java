package test1;

public class Sugar extends Bread {

	@Override
	public String BreadType() {
		
		return "sugar";
	}

}
