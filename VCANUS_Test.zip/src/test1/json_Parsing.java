package test1;

import org.json.simple.*;

public class json_Parsing {
	
	public JSONObject BreadType(Bread breadType) {
		//json 타입 데이터 생성
//		cream생성 
//		---생성---
//		{"recipe":{"flour":100,"cream":200,"water":100},"breadType":"cream"}
//		System.out.println(breadType.BreadType()+"생성 ");
		JSONObject data2 = new JSONObject();
		switch (breadType.BreadType()) {
		case "cream":
			data2.put("flour", 100);
			data2.put("water", 100);
			data2.put("cream", 200);
			break;
		case "sugar":
			data2.put("flour", 100);
			data2.put("water", 50);
			data2.put("sugar", 200);
			break;
		case "butter":
			data2.put("flour", 100);
			data2.put("water", 100);
			data2.put("butter", 50);
			break;
		}
		JSONObject data1 = new JSONObject();
		data1.put("breadType", breadType.BreadType());
		data1.put("recipe", data2);
		
		//System.out.println(data1);
//		System.out.println("---생성---");
//		System.out.println(data1);
		return data1;
	}
	
	
	
}
