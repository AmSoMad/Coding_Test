package test1;

public class Cream extends Bread {

	@Override
	public String BreadType() {
		
		return "cream";
	}

}
