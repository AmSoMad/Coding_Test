package test1;


public abstract class BreadFactory {
	
	abstract Bread BreadType(String BreadType);

	
	
}
