package test1;

public abstract class Bread {
	
	
	public abstract String BreadType();
	
	
	
	
	
}
