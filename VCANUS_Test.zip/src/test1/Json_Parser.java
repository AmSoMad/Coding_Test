package test1;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Json_Parser {
	String outString;
	
	public void Parser(JSONObject data1) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject stringObject = (JSONObject)parser.parse(data1.toJSONString());
		JSONObject stJsonObject2 =(JSONObject)stringObject.get("recipe");
//		System.out.println(stringObject);
//		System.out.println(stJsonObject2);
		String breadType =(String)stringObject.get("breadType");
		String recipe_flour =Long.toString((long) stJsonObject2.get("flour"));
		String recipe_water =Long.toString((long) stJsonObject2.get("water"));
		String recipeType =Long.toString((long) stJsonObject2.get(breadType));
		System.out.println("breadType: "+breadType);
		System.out.println("recipe");
		System.out.println("flour: "+recipe_flour);
		System.out.println("water: "+recipe_water);
		System.out.println(breadType+": "+recipeType);
		System.out.println();
	}
}
