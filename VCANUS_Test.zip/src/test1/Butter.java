package test1;

public class Butter extends Bread {

	@Override
	public String BreadType() {
		
		return "butter";
	}

}
