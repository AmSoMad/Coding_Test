package test1;

public class BreadFactory_Making extends BreadFactory {

	@Override
	Bread BreadType(String BreadType) {
		if(BreadType.equals("sugar")) {
			return new Sugar();
		}else if(BreadType.equals("butter")) {
			return new Butter();
		}else if(BreadType.equals("cream")) {
			return new Cream();
		}
		
		return null;
	}
	
	

	
}
