package test1;

import org.json.simple.parser.ParseException;

public class BreadFactoryMain {

	public static void main(String[] args) throws ParseException {
//		String Type1 = "cream";
//		String Type2 = "sugar";
//		String Type3 = "butter";
		json_Parsing jp = new json_Parsing();
		BreadFactory bm = new BreadFactory_Making();
		String Type[] = {"cream","sugar","butter"};
		Json_Parser json_Parser = new Json_Parser();
		Bread b1 = null;
		for(int i = 0; i < 3; i++) {
		b1 = bm.BreadType(Type[i]);
		jp.BreadType(b1);
		json_Parser.Parser(jp.BreadType(b1));
		}
	}

}
