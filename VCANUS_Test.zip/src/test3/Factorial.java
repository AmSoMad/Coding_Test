package test3;

public class Factorial {
	
	public static void main(String[] args) {
		long num = 4;
		System.out.println(f_factorial(num));
	}
	
	public static long f_factorial(long num) {
		if(num > 1) {
			return num *= f_factorial(num - 1);
		}
		return 1; 
	}

}
