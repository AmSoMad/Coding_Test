package test2;

public class chaining {
	
	public static void main(String[] args) {
		add_subtract add_subtract = new add_subtract();
		
		int result = add_subtract.Add(4).Add(5).Subtract(3).Out();
		System.out.println(result);

	}
	
}
