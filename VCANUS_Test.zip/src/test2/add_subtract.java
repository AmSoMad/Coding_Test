package test2;

public class add_subtract {

	private int add = 0;
	private int subNumber = 0;
	private int result = 0;
	public add_subtract Add(int add) { //더하기
		this.add += add;
		return this;
	}
	public add_subtract Subtract(int subNumber) { //빼기
		this.subNumber -= subNumber;
		return this;
	}

	public int Out() {
		return result = add+subNumber;
	}

}
