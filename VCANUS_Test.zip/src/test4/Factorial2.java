package test4;

import java.util.ArrayList;

public class Factorial2 {
	static int arrayNum = 0;
	static int MaxArray = 1;

	public static void main(String[] args) {
		int num = 14;
		String result2 = "";
		ArrayList result = sum(num);
		for(int i = result.size(); i > 0; i--) {
			result2 += Long.toString((long) result.get(i-1));
			
		}
		System.out.println(result2);
		//정답 제출 :
		//10억단위 혹은 1억단위마다 add 추가하여 추가.
		
		//****************
		//[178291200, 87]
		//87178291200
		//****************
	}

	// 10팩토리얼 = 3628800 
	// 14팩토리얼 = 87,178,291,200  [178,291,200, ]
	@SuppressWarnings("rawtypes") //arraylist 불특정경고해제
	public static ArrayList sum(int num) {
		int count1 = 0; //10억이상 수치
		long count2 = 0;
		Long MaxNum = (long) 1;
		ArrayList<Long> Factorial_array = new ArrayList<Long>();
		Factorial_array.add((long) 1);
		Factorial_array.add((long) 1);
		System.out.println("시작");
		for (int i = 1; i <= num; i++) {
			if (Factorial_array.get(arrayNum) > 0) {//1
				//여기서 1부터 곱한다.
				Factorial_array.set(arrayNum, Factorial_array.get(arrayNum) * i);
				if(count1 == 1) { //10억이상수치이면 탄다.
					for(int y = 1; y < Factorial_array.size(); y++) {
						Factorial_array.set(y, Factorial_array.get(y) * i);
						count2 = Factorial_array.get(y);
						//System.out.println("여긴 10억이상단위");
						//System.out.println(count2);
					}
				}
				if (Factorial_array.get(0) > 1000000000) {
					if(count1 > 0) {
						Factorial_array.set(count1, (Factorial_array.get(arrayNum) / 1000000000));
						Factorial_array.set(arrayNum, Factorial_array.get(arrayNum) % (Factorial_array.get(count1)*1000000000));	
					}
					//10억이 넘으면 카운트 추가 1
					if(count1 == 0) {		
					count1++;				
					Factorial_array.set(count1, (Factorial_array.get(arrayNum) / 1000000000));
					//System.out.println(Factorial_array.get(count1));
					}
				}
			}//1

		}
//		System.out.println("계산 결과 = ");
		System.out.println(Factorial_array.toString());
		return Factorial_array;
	}

}
