package test5;

public class Pond {

	public static void main(String[] args) {
		int up = 0;
		int down = 0;
		int left = 0;
		int right = 0;
		int result = 0;
		int input[] = {
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
				0, 0, 0, 1, 1, 1, 0, 0, 0, 0,
				0, 1, 1, 1, 1, 1, 1, 0, 0, 0,
				0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
				0, 1, 1, 1, 1, 1, 1, 1, 1, 0,
				0, 0, 1, 1, 1, 1, 1, 1, 0, 0,
				0, 0, 0, 1, 1, 1, 1, 0, 0, 0,
				0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; 
		int pond[][] = new int[10][10];
		for(int i = 0; i < 10; i++) {
    		for(int j = 0; j < 10; j++) {
    			pond[i][j] = input[(i*10)+j];
    		}
    	}
		for(int i = 1; i < 11; i++) {
				for(int j = 1; j < 11; j++) {
					if((i % 10) == 0 || (j % 10) == 0) {
						System.out.println(pond[i-1][j-1]);
					}else {
						System.out.print(pond[i-1][j-1]);
					}
				}
		}
		for(int i = 0; i < 10; i++) {
			for(int j = 0; j < 10; j++) {
				if(i > -1 && i < 9 || j > -1 && j < 9) {
					if(i == 0) {
						up = pond[i][j];
					}else {
						up = pond[i-1][j];
					}
					if(i == 9) {
						down = pond[i][j];
					}else {
						down = pond[i+1][j];
					}
					if(j ==0) {
						left = pond[i][j];
					}else {
						left = pond[i][j-1];
					}
					if(j ==9) {
						right = pond[i][j];
					}else {
						right = pond[i][j+1];
					}
					if((pond[i][j]) <= up+down+left+right) {
						pond[i][j]++;
					}
				}	
			}
		}
		for(int i = 1; i < 11; i++) {
			for(int j = 1; j < 11; j++) {
				if((i % 10) == 0 || (j % 10) == 0) {
					System.out.println(pond[i-1][j-1]);
					result += pond[i-1][j-1];
				}else {
					System.out.print(pond[i-1][j-1]);
					result += pond[i-1][j-1];
				}
			}
		System.out.println("상하좌우 4방면기준으로 카운트 올렸으므로 총면적값에 나누기 2를 하면 된다.");
		System.out.println(result/2 + "정답");
		//68
	}	
	}

}
